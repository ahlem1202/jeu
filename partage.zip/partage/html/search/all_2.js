var searchData=
[
  ['deplacement_5fobjet',['deplacement_objet',['../scrolling_8c.html#a326070ea1c05e146d232d831d8b31add',1,'deplacement_objet(Objet *objet, int *running):&#160;scrolling.c'],['../scrolling_8h.html#a326070ea1c05e146d232d831d8b31add',1,'deplacement_objet(Objet *objet, int *running):&#160;scrolling.c']]]
];
