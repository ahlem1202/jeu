var searchData=
[
  ['scrolling_2ec',['scrolling.c',['../scrolling_8c.html',1,'']]],
  ['scrolling_2eh',['scrolling.h',['../scrolling_8h.html',1,'']]],
  ['scrolling_5fdroit',['scrolling_droit',['../scrolling_8c.html#a610615c1db8b27253bd1a92619cba712',1,'scrolling_droit(SDL_Surface *screen, Objet *map, SDL_Rect *pos, Objet *boat):&#160;scrolling.c'],['../scrolling_8h.html#a610615c1db8b27253bd1a92619cba712',1,'scrolling_droit(SDL_Surface *screen, Objet *map, SDL_Rect *pos, Objet *boat):&#160;scrolling.c']]],
  ['scrolling_5fgauche',['scrolling_gauche',['../scrolling_8c.html#af84ab34093d4babe8afbdb32a3faab1f',1,'scrolling_gauche(SDL_Surface *screen, Objet *map, SDL_Rect *pos, Objet *boat):&#160;scrolling.c'],['../scrolling_8h.html#af84ab34093d4babe8afbdb32a3faab1f',1,'scrolling_gauche(SDL_Surface *screen, Objet *map, SDL_Rect *pos, Objet *boat):&#160;scrolling.c']]],
  ['setup',['setup',['../scrolling_8c.html#ab79683685c7ff28aa21a69af89757f98',1,'setup(SDL_Surface *screen, Objet *map, Objet *wood, Objet *boat, Objet *map2, Objet *perso):&#160;scrolling.c'],['../scrolling_8h.html#ab79683685c7ff28aa21a69af89757f98',1,'setup(SDL_Surface *screen, Objet *map, Objet *wood, Objet *boat, Objet *map2, Objet *perso):&#160;scrolling.c']]]
];
