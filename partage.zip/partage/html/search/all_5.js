var searchData=
[
  ['initialiser',['initialiser',['../scrolling_8c.html#afba8c0f01507d2a24008ca456b56d346',1,'initialiser(Objet *perso, Objet *map, Objet *wood, Objet *boat, Objet *map2, Objet *failed):&#160;scrolling.c'],['../scrolling_8h.html#afba8c0f01507d2a24008ca456b56d346',1,'initialiser(Objet *perso, Objet *map, Objet *wood, Objet *boat, Objet *map2, Objet *failed):&#160;scrolling.c']]]
];
