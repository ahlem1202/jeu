var searchData=
[
  ['affichage',['affichage',['../scrolling_8c.html#afcad6f94e89302ab712792ed4c850beb',1,'affichage(SDL_Surface *screen, Objet *boat, Objet *wood, Objet *map, Objet *map2, Objet *perso):&#160;scrolling.c'],['../scrolling_8h.html#afcad6f94e89302ab712792ed4c850beb',1,'affichage(SDL_Surface *screen, Objet *boat, Objet *wood, Objet *map, Objet *map2, Objet *perso):&#160;scrolling.c']]]
];
