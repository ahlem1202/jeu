var indexSectionsWithContent =
{
  0: "acdefimops",
  1: "co",
  2: "mps",
  3: "acdefis"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions"
};

