var searchData=
[
  ['coordinate',['Coordinate',['../structCoordinate.html',1,'Coordinate'],['../structcoordinate.html',1,'coordinate']]]
];
