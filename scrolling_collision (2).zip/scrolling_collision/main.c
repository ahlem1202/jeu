#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "scrolling.h"
#include "Perfect_Collision.h"


int main()
{
SDL_Surface *screen = NULL ;
Objet map,wood,boat,map2,failed ;
SDL_Rect pos ;
Coordinate C ;
int running=1,collision3=0,running8=1 ;
SDL_Event event ;
FILE *f ;

 f=fopen("test.txt","a") ;

 screen= SDL_SetVideoMode(width, height, 32, SDL_HWSURFACE|SDL_DOUBLEBUF  );
 
  
  initialiser (&map ,&wood ,&boat,&map2,&failed ) ;
  setup (screen,&map ,&wood,&boat,&map2) ;

  SDL_EnableKeyRepeat(10, 10);
  while(running){
      if(map.pos.x<=0 )
         {
               
          deplacement_objet(&wood,&running) ;
          setup (screen,&map,&wood,&boat,&map2) ;
          if(wood.pos.x>=500)
          {
           pos=wood.pos ;
           evenement (screen ,&boat ,&wood,&map,&running,&pos,&map2 ) ;
          }
         }

       else if(map.pos.x>=mapw-1368)
       {

            deplacement_objet(&wood,&running) ;
          

            affichage (screen,&boat ,&wood,&map,&map2) ;
              //SDL_Flip(screen) ;
            
            
            if(wood.pos.x<=500)
            {
              
              evenement (screen ,&boat ,&wood,&map,&running,&pos,&map2 ) ;
               
            }
       } 
       else
         {             
             evenement (screen ,&boat ,&wood,&map,&running ,&pos,&map2) ;
             
         } 
             C.X=pos.x+50 ;
             C.Y=pos.y+(wood.img->h /2) ;
             
             collision3=Collision_Parfaite(map.img,C) ;
             if(collision3)
              {
                fprintf(f,"c.x=%d c.y= %d",C.X,C.Y) ;
               
                while(running8){
                  SDL_BlitSurface(failed.img, NULL, screen, &(failed.pos));
                SDL_Flip(screen) ;
                SDL_WaitEvent(&event) ;
                        switch(event.type)
              {
                case SDL_QUIT:
                running8 = 0 ;
                    running=0 ;
                break;
                case SDL_KEYDOWN :
              switch(event.key.keysym.sym)
               {
                 case SDLK_ESCAPE:
                    running8=0 ;
                     affichage (screen,&boat ,&wood,&map,&map2) ;
                  break ;
               }
               break ;
              } 
                }
                affichage (screen,&boat ,&wood,&map,&map2) ; 
                SDL_Flip(screen) ;
              } 
      
     }
    free_memory (&boat ,&wood,&map,&map2) ;

    
    fclose(f) ;
    return EXIT_SUCCESS;
}
